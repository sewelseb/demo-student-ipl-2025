// src/index.ts
import express from 'express';

import {tasksController} from './controllers/tasks.controller';

const app = express();
const port = 3000;

app.use(express.json());

app.get('/', (_req, res) => {
  res.send('Hello TypeScript + Express!');
});

// use the controller to use the route
app.use('/tasks', tasksController);


app.listen(port, () => {
  console.log(`Serveur lancé sur http://localhost:${port}`);
});

export default app;